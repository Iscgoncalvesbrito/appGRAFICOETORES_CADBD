<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$host = "localhost";
$user = "root";
$pass = "";
$db = "grafico_sapatos";

$conexao = new mysqli($host, $user, $pass, $db);

if ($conexao->connect_error) {
    die(json_encode([
        "erro" => "Falha na conexão"
    ]));
}

$sql = "SELECT marca, quantidade FROM vendas";

$resultado = $conexao->query($sql);

$dados = [];

while ($linha = $resultado->fetch_assoc()) {
    $dados[] = $linha;
}

echo json_encode($dados);

$conexao->close();

?>