<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    exit;
}

$host = "localhost";
$user = "root";
$pass = "";
$db = "grafico_sapatos";

$conexao = new mysqli($host, $user, $pass, $db);

if ($conexao->connect_error) {
    die(json_encode([
        "sucesso" => false,
        "mensagem" => "Falha na conexão"
    ]));
}

$dados = json_decode(file_get_contents("php://input"), true);

$marca = $dados["marca"] ?? "";
$quantidade = $dados["quantidade"] ?? "";

if ($marca == "" || $quantidade == "") {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Preencha todos os campos"
    ]);

    exit;
}

$sql = "INSERT INTO vendas (marca, quantidade)
        VALUES (?, ?)";

$stmt = $conexao->prepare($sql);

$stmt->bind_param(
    "si",
    $marca,
    $quantidade
);

if ($stmt->execute()) {

    echo json_encode([
        "sucesso" => true,
        "mensagem" => "Venda cadastrada com sucesso"
    ]);

} else {

    echo json_encode([
        "sucesso" => false,
        "mensagem" => "Erro ao cadastrar"
    ]);

}

$stmt->close();
$conexao->close();

?>